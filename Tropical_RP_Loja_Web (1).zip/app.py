import os, sqlite3, secrets, json
from functools import wraps
from flask import Flask, g, render_template, request, redirect, url_for, session, flash, abort
import requests

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-before-deploying")
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(os.path.dirname(__file__), "tropical.db"))
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "change-me-now")
MP_ACCESS_TOKEN = os.environ.get("MP_ACCESS_TOKEN", "")
PUBLIC_BASE_URL = os.environ.get("PUBLIC_BASE_URL", "http://127.0.0.1:5000")

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL,
        price INTEGER NOT NULL DEFAULT 0, description TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
        payment_type TEXT NOT NULL DEFAULT 'both')""")
    conn.execute("""CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT NOT NULL, product_id INTEGER,
        product_name TEXT NOT NULL, amount INTEGER NOT NULL, payment_method TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending', external_url TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
    count = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    if count == 0:
        seeds = [
            ("BMW M5 F90","BMW",12000000,"Sedã esportivo premium",1,"both"),
            ("Porsche 911 Turbo S","Esportivo & Luxo",25000000,"Esportivo de alto desempenho",1,"both"),
            ("Ford Explorer Utility","Policial",8000000,"SUV utilitário policial",1,"game"),
            ("Saveiro Cross","Dia a dia",25000,"Veículo inicial; sistema de música depende do jogo",1,"game"),
            ("VIP Bronze","VIP",450000,"Plano VIP de 30 dias",1,"both"),
            ("VIP Silver","VIP",1200000,"Plano VIP de 30 dias",1,"both"),
        ]
        conn.executemany("INSERT INTO products(name,category,price,description,active,payment_type) VALUES(?,?,?,?,?,?)", seeds)
    conn.commit()
    conn.close()

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapper

@app.template_filter("money")
def money(value):
    return f"{int(value):,}".replace(",", ".")

@app.route("/")
def index():
    products = db().execute("SELECT * FROM products WHERE active=1 ORDER BY category,name").fetchall()
    categories = sorted(set(p["category"] for p in products))
    return render_template("index.html", products=products, categories=categories)

@app.route("/pedido/<int:product_id>", methods=["GET", "POST"])
def order(product_id):
    product = db().execute("SELECT * FROM products WHERE id=? AND active=1", (product_id,)).fetchone()
    if not product:
        abort(404)
    if request.method == "POST":
        customer = request.form.get("customer", "").strip()[:80]
        method = request.form.get("payment_method", "")
        if not customer:
            flash("Informe seu nome ou usuário no jogo.", "error")
            return redirect(url_for("order", product_id=product_id))
        if method not in ("game", "pix"):
            flash("Escolha uma forma de pagamento válida.", "error")
            return redirect(url_for("order", product_id=product_id))
        if product["payment_type"] == "game" and method != "game":
            flash("Este produto só aceita dinheiro do jogo.", "error")
            return redirect(url_for("order", product_id=product_id))
        if product["payment_type"] == "real" and method != "pix":
            flash("Este produto só aceita pagamento em dinheiro real.", "error")
            return redirect(url_for("order", product_id=product_id))
        cur = db().execute("""INSERT INTO orders(customer,product_id,product_name,amount,payment_method,status)
            VALUES(?,?,?,?,?,?)""", (customer, product_id, product["name"], product["price"], method, "pending"))
        order_id = cur.lastrowid
        db().commit()
        if method == "pix":
            if not MP_ACCESS_TOKEN:
                flash(f"Pedido #{order_id} criado. Pix ainda não está conectado: configure MP_ACCESS_TOKEN nas variáveis de ambiente.", "warning")
                return redirect(url_for("order_status", order_id=order_id))
            try:
                preference = {
                    "items": [{"title": f"Tropical RP - {product['name']}", "quantity": 1,
                               "currency_id": "BRL", "unit_price": round(product["price"] / 100, 2)}],
                    "external_reference": str(order_id),
                    "back_urls": {"success": f"{PUBLIC_BASE_URL}/pedido-status/{order_id}",
                                  "failure": f"{PUBLIC_BASE_URL}/pedido-status/{order_id}",
                                  "pending": f"{PUBLIC_BASE_URL}/pedido-status/{order_id}"},
                    "auto_return": "approved",
                    "notification_url": f"{PUBLIC_BASE_URL}/webhook/mercadopago"
                }
                response = requests.post("https://api.mercadopago.com/checkout/preferences",
                    headers={"Authorization": f"Bearer {MP_ACCESS_TOKEN}", "Content-Type": "application/json"},
                    json=preference, timeout=20)
                response.raise_for_status()
                payload = response.json()
                db().execute("UPDATE orders SET external_url=? WHERE id=?", (payload.get("init_point",""), order_id))
                db().commit()
                return redirect(payload.get("init_point") or url_for("order_status", order_id=order_id))
            except Exception:
                app.logger.exception("Mercado Pago preference creation failed")
                flash("Não foi possível gerar o checkout Pix. O pedido foi registrado como pendente.", "error")
        return redirect(url_for("order_status", order_id=order_id))
    return render_template("order.html", product=product)

@app.route("/pedido-status/<int:order_id>")
def order_status(order_id):
    item = db().execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not item:
        abort(404)
    return render_template("order_status.html", order=item)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if secrets.compare_digest(request.form.get("username",""), ADMIN_USER) and secrets.compare_digest(request.form.get("password",""), ADMIN_PASSWORD):
            session.clear()
            session["admin"] = True
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Usuário ou senha incorretos.", "error")
    return render_template("login.html")

@app.route("/sair")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/admin")
@admin_required
def dashboard():
    conn = db()
    products = conn.execute("SELECT * FROM products ORDER BY category,name").fetchall()
    orders = conn.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 100").fetchall()
    return render_template("admin.html", products=products, orders=orders)

@app.route("/admin/produto", methods=["POST"])
@admin_required
def add_product():
    name = request.form.get("name","").strip()[:100]
    category = request.form.get("category","Outros").strip()[:60]
    description = request.form.get("description","").strip()[:500]
    try:
        price = int(request.form.get("price","0"))
    except ValueError:
        price = -1
    payment_type = request.form.get("payment_type","both")
    if not name or price < 0 or payment_type not in ("game","real","both"):
        flash("Confira nome, preço e tipo de pagamento.", "error")
    else:
        db().execute("INSERT INTO products(name,category,price,description,active,payment_type) VALUES(?,?,?,?,1,?)",
                     (name, category or "Outros", price, description, payment_type))
        db().commit()
        flash("Produto adicionado.", "success")
    return redirect(url_for("dashboard"))

@app.route("/admin/produto/<int:product_id>", methods=["POST"])
@admin_required
def edit_product(product_id):
    action = request.form.get("action")
    conn = db()
    product = conn.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
    if not product:
        abort(404)
    if action == "delete":
        conn.execute("DELETE FROM products WHERE id=?", (product_id,))
        flash("Produto removido.", "success")
    elif action == "toggle":
        conn.execute("UPDATE products SET active=? WHERE id=?", (0 if product["active"] else 1, product_id))
        flash("Visibilidade atualizada.", "success")
    elif action == "save":
        name = request.form.get("name","").strip()[:100]
        category = request.form.get("category","Outros").strip()[:60]
        description = request.form.get("description","").strip()[:500]
        try:
            price = int(request.form.get("price","0"))
        except ValueError:
            price = -1
        payment_type = request.form.get("payment_type","both")
        if not name or price < 0 or payment_type not in ("game","real","both"):
            flash("Dados inválidos. Preço deve ser um número inteiro.", "error")
            return redirect(url_for("dashboard"))
        conn.execute("UPDATE products SET name=?,category=?,price=?,description=?,payment_type=? WHERE id=?",
                     (name, category or "Outros", price, description, payment_type, product_id))
        flash("Produto atualizado.", "success")
    conn.commit()
    return redirect(url_for("dashboard"))

@app.route("/admin/pedido/<int:order_id>", methods=["POST"])
@admin_required
def update_order(order_id):
    status = request.form.get("status")
    if status not in ("pending", "approved", "cancelled"):
        abort(400)
    db().execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
    db().commit()
    flash("Status do pedido atualizado.", "success")
    return redirect(url_for("dashboard"))

@app.route("/webhook/mercadopago", methods=["POST"])
def mercadopago_webhook():
    # Segurança: o webhook apenas registra o evento recebido. Para aprovação automática,
    # implemente a consulta autenticada do pagamento pela API e valide o external_reference.
    # Nunca confie apenas no retorno do navegador ou no corpo não verificado do webhook.
    app.logger.info("Mercado Pago webhook received")
    return "received", 200

@app.route("/health")
def health():
    return {"status": "ok"}

with app.app_context():
    init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)

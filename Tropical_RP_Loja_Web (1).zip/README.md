# 🌴 Tropical RP — Loja web

Projeto inicial executável com catálogo público, pedidos, painel de administração, controle de permissões por login e integração inicial com Mercado Pago Checkout Pro.

## O que já está incluído
- Catálogo por categoria e preços editáveis no painel.
- Criar, editar, ocultar/reativar e remover produtos.
- Produtos podem aceitar dinheiro do jogo, pagamento real ou ambos.
- Criar pedidos e consultar o status.
- Painel administrativo protegido por usuário e senha.
- Gestão manual de status de pedidos.
- Integração inicial para criar preferência de checkout Mercado Pago quando `MP_ACCESS_TOKEN` estiver configurado.
- Arquivo `render.yaml` para facilitar o deploy em um serviço compatível com Render.

## Limitações importantes
- **Não está hospedado** e não existe URL pública até você fazer o deploy.
- O pagamento real precisa de uma conta de vendedor no Mercado Pago e credenciais próprias. Não coloque tokens no código nem compartilhe-os.
- A rota de webhook é apenas um esqueleto seguro: não aprova pagamentos automaticamente. Antes de usar em produção, implemente validação autenticada consultando o pagamento pela API do Mercado Pago e verificando `external_reference`, valor e status.
- Os preços são inteiros em unidades configuradas pela loja. Para checkout real, o exemplo interpreta o valor como centavos de real (`price / 100`). Ajuste isso se seus preços forem valores do jogo ou se sua política de preço real for diferente. **Não cobre dinheiro real por itens virtuais sem verificar as regras aplicáveis da plataforma e do jogo.**
- A opção “dinheiro do jogo” apenas registra o pedido; não consegue debitar saldo nem entregar veículo/VIP automaticamente sem integração com a API do jogo.
- O login de admin é único, via variáveis de ambiente; não há ainda múltiplos donos, recuperação de senha ou 2FA.
- SQLite funciona bem para testes locais, mas armazenamento em hospedagem gratuita pode ser efêmero. Para uma loja pública, use banco persistente (por exemplo PostgreSQL gerenciado) e configure backups.

## Executar no computador
Requer Python 3.10+.

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

Configure as variáveis de ambiente antes de iniciar. No Windows PowerShell:

```powershell
$env:SECRET_KEY="coloque-uma-chave-longa"
$env:ADMIN_USER="admin"
$env:ADMIN_PASSWORD="coloque-uma-senha-forte"
$env:PUBLIC_BASE_URL="http://127.0.0.1:5000"
python app.py
```

Abra `http://127.0.0.1:5000`. O painel é `http://127.0.0.1:5000/login`.

## Hospedagem gratuita (instruções gerais)
1. Crie um repositório privado no GitHub e envie os arquivos do projeto.
2. Crie um serviço Web no Render e conecte o repositório.
3. Use o build command `pip install -r requirements.txt` e o start command `gunicorn app:app`.
4. Defina `SECRET_KEY`, `ADMIN_USER`, `ADMIN_PASSWORD` e `PUBLIC_BASE_URL` nas variáveis de ambiente. Use como `PUBLIC_BASE_URL` a URL HTTPS fornecida pelo host.
5. Para checkout real, configure `MP_ACCESS_TOKEN` com credencial de produção do Mercado Pago apenas depois de testar no ambiente de teste.
6. Antes de abrir ao público, configure banco PostgreSQL persistente e altere o app para usar esse banco. O disco local gratuito pode ser apagado em reinicializações/redeploys e alguns planos gratuitos podem suspender o serviço ocioso.

## Segurança antes de lançar
- Troque a senha padrão; nunca use `change-me-now`.
- Não publique `.env` nem tokens.
- Adicione verificação real de assinatura/consulta do webhook do Mercado Pago antes de marcar pagamentos como aprovados.
- Não entregue itens com base em comprovante enviado pelo cliente; confirme pela API.
- Faça testes com valores baixos e credenciais de teste primeiro.
